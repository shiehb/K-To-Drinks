"use client"

import Link from "next/link"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="text-xl font-bold text-amber-600">
            ARQUILITAS
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-4">
            <Link href="/" className="text-gray-700 hover:text-amber-600">
              Home
            </Link>
            <Link href="/menu" className="text-gray-700 hover:text-amber-600">
              Menu
            </Link>
            <Link href="/about" className="text-gray-700 hover:text-amber-600">
              About
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-amber-600">
              Contact
            </Link>
            <Button asChild className="bg-amber-600 hover:bg-amber-700 ml-4">
              <Link href="/login">Login</Link>
            </Button>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-gray-700"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden py-4 space-y-2">
            <Link
              href="/"
              className="block px-2 py-1 text-gray-700 hover:text-amber-600"
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              href="/menu"
              className="block px-2 py-1 text-gray-700 hover:text-amber-600"
              onClick={() => setIsMenuOpen(false)}
            >
              Menu
            </Link>
            <Link
              href="/about"
              className="block px-2 py-1 text-gray-700 hover:text-amber-600"
              onClick={() => setIsMenuOpen(false)}
            >
              About
            </Link>
            <Link
              href="/contact"
              className="block px-2 py-1 text-gray-700 hover:text-amber-600"
              onClick={() => setIsMenuOpen(false)}
            >
              Contact
            </Link>
            <Button
              asChild
              className="w-full bg-amber-600 hover:bg-amber-700 mt-2"
              onClick={() => setIsMenuOpen(false)}
            >
              <Link href="/login">Login</Link>
            </Button>
          </nav>
        )}
      </div>
    </header>
  )
}
