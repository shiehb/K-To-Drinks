import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

// Define paths that require authentication
const protectedPaths = ["/dashboard", "/account", "/admin", "/checkout"]

export function middleware(request: NextRequest) {
  const path = request.nextUrl.pathname

  // Get token from cookies
  const token = request.cookies.get("token")?.value

  // Check if user is trying to access a protected path
  if (protectedPaths.some((prefix) => path.startsWith(prefix))) {
    // If no token exists, redirect to login
    if (!token) {
      return NextResponse.redirect(new URL("/login", request.url))
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public (public files)
     */
    "/((?!_next/static|_next/image|favicon.ico|public).*)",
  ],
}
