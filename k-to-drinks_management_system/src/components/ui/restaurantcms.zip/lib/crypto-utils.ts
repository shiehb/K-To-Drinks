import crypto from "crypto"

// Hardcoded secret key - in a production app, this would be an environment variable
const SECRET_KEY = "this-is-a-secure-key-for-encryption-32"

// Ensure the key is exactly 32 bytes (256 bits) for AES-256
const getKey = () => {
  return Buffer.from(SECRET_KEY.padEnd(32).slice(0, 32))
}

// Encrypt data
export function encrypt(text: string): string {
  try {
    const iv = crypto.randomBytes(16) // Initialization vector
    const key = getKey()
    const cipher = crypto.createCipheriv("aes-256-cbc", key, iv)

    let encrypted = cipher.update(text, "utf8", "hex")
    encrypted += cipher.final("hex")

    // Return IV + encrypted data (IV is needed for decryption)
    return iv.toString("hex") + ":" + encrypted
  } catch (error) {
    console.error("Encryption error:", error)
    throw new Error("Failed to encrypt data")
  }
}

// Decrypt data
export function decrypt(encryptedText: string): string {
  try {
    const [ivHex, encrypted] = encryptedText.split(":")
    const iv = Buffer.from(ivHex, "hex")
    const key = getKey()
    const decipher = crypto.createDecipheriv("aes-256-cbc", key, iv)

    let decrypted = decipher.update(encrypted, "hex", "utf8")
    decrypted += decipher.final("utf8")

    return decrypted
  } catch (error) {
    console.error("Decryption error:", error)
    throw new Error("Failed to decrypt data")
  }
}
