// This is a secure authentication utility
// In a production application, you would implement proper authentication with JWT, OAuth, etc.

import { cookies } from "next/headers"
import { encrypt, decrypt } from "./crypto-utils"

interface AuthResult {
  success: boolean
  token?: string
  role?: string
  message?: string
  user?: {
    id: string
    name: string
    email: string
    role: string
  }
}

interface UserData {
  firstName: string
  lastName: string
  email: string
  phone: string
  region: string
  password: string
  confirmPassword?: string
}

// Mock user database - in a real app, this would be in a database
const users = [
  {
    id: "1",
    email: "user@example.com",
    password: "password", // In a real app, this would be hashed
    role: "user",
    name: "Regular User",
    phone: "123-456-7890",
    region: "ncr",
  },
  {
    id: "2",
    email: "admin@example.com",
    password: "admin",
    role: "admin",
    name: "Admin User",
    phone: "987-654-3210",
    region: "region4a",
  },
]

export async function loginUser(email: string, password: string): Promise<AuthResult> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // Find user in mock database
  const user = users.find((u) => u.email === email && u.password === password)

  if (user) {
    // Generate a token with user information
    const token = encrypt(
      JSON.stringify({
        id: user.id,
        email: user.email,
        role: user.role,
        exp: Date.now() + 24 * 60 * 60 * 1000, // 24 hours expiration
      }),
    )

    // Set cookies for server-side auth
    const cookieStore = cookies()
    cookieStore.set("authToken", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: 24 * 60 * 60, // 24 hours
      path: "/",
      sameSite: "strict",
    })

    cookieStore.set("userRole", user.role, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: 24 * 60 * 60, // 24 hours
      path: "/",
      sameSite: "strict",
    })

    return {
      success: true,
      token,
      role: user.role,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    }
  }

  return {
    success: false,
    message: "Invalid email or password",
  }
}

export async function registerUser(userData: UserData): Promise<AuthResult> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 1500))

  // Check if user already exists
  const userExists = users.some((u) => u.email === userData.email)

  if (userExists) {
    return {
      success: false,
      message: "User with this email already exists",
    }
  }

  // In a real app, you would hash the password and save the user to a database
  // Here we're just simulating a successful registration
  const newUser = {
    id: `${users.length + 1}`,
    email: userData.email,
    password: userData.password, // In a real app, this would be hashed
    role: "user",
    name: `${userData.firstName} ${userData.lastName}`,
    phone: userData.phone,
    region: userData.region,
  }

  // Add user to our mock database
  users.push(newUser)

  return {
    success: true,
    message: "Registration successful",
  }
}

export async function getCurrentUser() {
  try {
    const cookieStore = cookies()
    const token = cookieStore.get("authToken")?.value

    if (!token) {
      return null
    }

    const userData = JSON.parse(decrypt(token))

    // Check if token is expired
    if (userData.exp < Date.now()) {
      return null
    }

    const user = users.find((u) => u.id === userData.id)
    if (!user) {
      return null
    }

    return {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
    }
  } catch (error) {
    console.error("Error getting current user:", error)
    return null
  }
}

export async function logoutUser() {
  const cookieStore = cookies()
  cookieStore.delete("authToken")
  cookieStore.delete("userRole")
}

export async function checkAuth(): Promise<boolean> {
  const user = await getCurrentUser()
  return !!user
}

export async function checkAdminAuth(): Promise<boolean> {
  const user = await getCurrentUser()
  return !!user && user.role === "admin"
}
