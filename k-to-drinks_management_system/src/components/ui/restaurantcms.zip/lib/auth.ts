import { SignJWT, jwtVerify } from "jose"
import { cookies } from "next/headers"
import type { NextRequest, NextResponse } from "next/server"
import bcrypt from "bcryptjs"

// Use environment variable with fallback for JWT secret
const JWT_SECRET = process.env.JWT_SECRET || "fallback-secret-do-not-use-in-production"

// Interface for user data
interface UserData {
  id: string
  email: string
  name: string
  role: string
}

// Generate JWT token
export async function generateToken(user: UserData): Promise<string> {
  try {
    const token = await new SignJWT({
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
    })
      .setProtectedHeader({ alg: "HS256" })
      .setIssuedAt()
      .setExpirationTime("24h")
      .sign(new TextEncoder().encode(JWT_SECRET))

    return token
  } catch (error) {
    console.error("Error generating token:", error)
    throw new Error("Failed to generate token")
  }
}

// Verify JWT token
export async function verifyToken(token: string): Promise<UserData | null> {
  try {
    const { payload } = await jwtVerify(token, new TextEncoder().encode(JWT_SECRET))

    return payload as UserData
  } catch (error) {
    console.error("Error verifying token:", error)
    return null
  }
}

// Set token in cookies
export function setTokenCookie(token: string, response?: NextResponse): void {
  const cookieStore = cookies()

  const cookieOptions = {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24, // 1 day
    path: "/",
  }

  if (response) {
    // For API routes
    response.cookies.set("token", token, cookieOptions)
  } else {
    // For server components
    cookieStore.set("token", token, cookieOptions)
  }
}

// Remove token from cookies
export function removeTokenCookie(response?: NextResponse): void {
  const cookieStore = cookies()

  if (response) {
    // For API routes
    response.cookies.delete("token")
  } else {
    // For server components
    cookieStore.delete("token")
  }
}

// Hash password
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10)
}

// Compare password with hash
export async function comparePasswords(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash)
}

// Get current user from request
export async function getCurrentUser(request: NextRequest): Promise<UserData | null> {
  const token = request.cookies.get("token")?.value

  if (!token) {
    return null
  }

  return verifyToken(token)
}
