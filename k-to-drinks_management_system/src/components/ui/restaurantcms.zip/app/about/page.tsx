import Image from "next/image"

export default function AboutPage() {
  return (
    <div className="container mx-auto py-12 px-4">
      <h1 className="text-3xl md:text-4xl font-bold text-center mb-12">About ARQUILITAS</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16">
        <div>
          <h2 className="text-2xl font-semibold mb-4">Our Story</h2>
          <p className="text-gray-600 mb-4">
            ARQUILITAS was founded in 2015 by Chef Maria Santos, who wanted to bring authentic Filipino cuisine to a
            wider audience. Born and raised in Manila, Maria learned traditional cooking techniques from her
            grandmother, who instilled in her a deep appreciation for Filipino culinary traditions.
          </p>
          <p className="text-gray-600">
            After studying culinary arts and working in renowned restaurants across Asia, Maria returned to her roots
            and opened ARQUILITAS with a mission to showcase the rich flavors and diverse influences that make Filipino
            cuisine so special.
          </p>
        </div>
        <div className="relative h-80 w-full rounded-lg overflow-hidden">
          <Image
            src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?q=80&w=2070&auto=format&fit=crop"
            alt="Restaurant interior"
            fill
            className="object-cover"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16">
        <div className="order-2 md:order-1 relative h-80 w-full rounded-lg overflow-hidden">
          <Image
            src="https://images.unsplash.com/photo-1555244162-803834f70033?q=80&w=2070&auto=format&fit=crop"
            alt="Filipino ingredients"
            fill
            className="object-cover"
          />
        </div>
        <div className="order-1 md:order-2">
          <h2 className="text-2xl font-semibold mb-4">Our Philosophy</h2>
          <p className="text-gray-600 mb-4">
            At ARQUILITAS, we believe in honoring traditional Filipino recipes while incorporating modern techniques and
            presentations. We source the freshest ingredients, including authentic Filipino products, to ensure that
            every dish delivers the true essence of Filipino cuisine.
          </p>
          <p className="text-gray-600">
            Our commitment to quality extends beyond our food. We strive to create a warm, welcoming atmosphere where
            guests can experience Filipino hospitality and culture through every aspect of their dining experience.
          </p>
        </div>
      </div>

      <div className="text-center mb-16">
        <h2 className="text-2xl font-semibold mb-8">Meet Our Team</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            {
              name: "Maria Santos",
              role: "Founder & Head Chef",
              image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=2070&auto=format&fit=crop",
            },
            {
              name: "Juan Reyes",
              role: "Executive Chef",
              image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=2070&auto=format&fit=crop",
            },
            {
              name: "Elena Cruz",
              role: "Pastry Chef",
              image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=2070&auto=format&fit=crop",
            },
          ].map((member) => (
            <div key={member.name} className="text-center">
              <div className="relative h-64 w-64 rounded-full overflow-hidden mx-auto mb-4">
                <Image src={member.image || "/placeholder.svg"} alt={member.name} fill className="object-cover" />
              </div>
              <h3 className="text-xl font-semibold">{member.name}</h3>
              <p className="text-gray-600">{member.role}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
