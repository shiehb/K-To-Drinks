"use client"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function CheckoutPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Checkout</h1>
      <hr className="mb-6" />

      <div className="grid md:grid-cols-3 gap-8">
        {/* Checkout Form */}
        <div className="md:col-span-2">
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4">PAYMENT</h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="bankType">BANK TYPE</Label>
                <Select>
                  <SelectTrigger id="bankType" className="w-full">
                    <SelectValue placeholder="Select bank" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bdo">BDO</SelectItem>
                    <SelectItem value="bpi">BPI</SelectItem>
                    <SelectItem value="metrobank">Metrobank</SelectItem>
                    <SelectItem value="gcash">GCash</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="accountName">ACCOUNT NAME</Label>
                <Input id="accountName" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="accountNumber">ACCOUNT NUMBER</Label>
                <Input id="accountNumber" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="expirationDate">EXPIRATION DATE</Label>
                  <Input id="expirationDate" placeholder="MM/YY" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cvv">CVV</Label>
                  <Input id="cvv" />
                </div>
              </div>

              <p className="text-sm text-gray-500">*For card payments</p>
            </div>
          </div>

          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4">CONTACT</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">FIRST NAME</Label>
                  <Input id="firstName" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">LAST NAME</Label>
                  <Input id="lastName" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phoneNumber">PHONE NUMBER</Label>
                <Input id="phoneNumber" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">EMAIL</Label>
                <Input id="email" type="email" />
              </div>
            </div>
          </div>

          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4">DELIVERY</h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="regionalBranch">REGIONAL BRANCH</Label>
                <Select>
                  <SelectTrigger id="regionalBranch" className="w-full">
                    <SelectValue placeholder="Select branch" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="manila">Manila</SelectItem>
                    <SelectItem value="quezon">Quezon City</SelectItem>
                    <SelectItem value="makati">Makati</SelectItem>
                    <SelectItem value="cebu">Cebu</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="city">CITY</Label>
                <Select>
                  <SelectTrigger id="city" className="w-full">
                    <SelectValue placeholder="Select city" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="manila">Manila</SelectItem>
                    <SelectItem value="quezon">Quezon City</SelectItem>
                    <SelectItem value="makati">Makati</SelectItem>
                    <SelectItem value="pasig">Pasig</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="barangay">BARANGAY</Label>
                  <Select>
                    <SelectTrigger id="barangay" className="w-full">
                      <SelectValue placeholder="Select barangay" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="barangay1">Barangay 1</SelectItem>
                      <SelectItem value="barangay2">Barangay 2</SelectItem>
                      <SelectItem value="barangay3">Barangay 3</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="postalCode">POSTAL CODE</Label>
                  <Input id="postalCode" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">BLOCK / LOT (Input exact location/landmark)</Label>
                <Input id="address" />
              </div>
            </div>
          </div>
        </div>

        {/* Order Summary */}
        <div className="md:col-span-1">
          <div className="border p-6">
            <h2 className="text-xl font-semibold mb-4">Order Summary</h2>

            <div className="space-y-3 mb-6">
              <div className="flex justify-between">
                <span>PRODUCT x 1</span>
                <span>PHP</span>
              </div>
              <div className="flex justify-between">
                <span>PRODUCT x 2</span>
                <span>PHP</span>
              </div>
              <div className="flex justify-between">
                <span>Shipping Fee</span>
                <span>PHP</span>
              </div>
              <div className="border-t pt-3 mt-3 flex justify-between font-semibold">
                <span>Total</span>
                <span>PHP</span>
              </div>
            </div>

            <Button asChild className="w-full bg-gray-700 hover:bg-gray-800">
              <Link href="/confirmation">PAY NOW</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
