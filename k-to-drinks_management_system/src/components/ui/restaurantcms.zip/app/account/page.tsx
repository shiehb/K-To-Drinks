"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useRouter } from "next/navigation"

// Sample order history data
const orderHistory = [
  {
    id: "ORD-12345",
    date: "May 9, 2025",
    total: "₱1,250.00",
    status: "Delivered",
    items: 3,
  },
  {
    id: "ORD-12344",
    date: "May 2, 2025",
    total: "₱850.00",
    status: "Delivered",
    items: 2,
  },
  {
    id: "ORD-12343",
    date: "April 25, 2025",
    total: "₱1,500.00",
    status: "Delivered",
    items: 4,
  },
]

export default function AccountPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("profile")
  const [isLoading, setIsLoading] = useState(false)

  // Mock user data
  const userData = {
    firstName: "Juan",
    lastName: "Dela Cruz",
    email: "juan@example.com",
    phone: "0917-123-4567",
    address: "123 Mabini St., Brgy. San Antonio",
    city: "Quezon City",
    region: "National Capital Region",
  }

  const handleLogout = () => {
    setIsLoading(true)

    // Simulate logout
    setTimeout(() => {
      router.push("/login")
    }, 1000)
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8">My Account</h1>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Sidebar */}
        <div className="md:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>
                {userData.firstName} {userData.lastName}
              </CardTitle>
              <CardDescription>{userData.email}</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs orientation="vertical" value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="flex flex-col items-start w-full">
                  <TabsTrigger value="profile" className="w-full justify-start">
                    Profile
                  </TabsTrigger>
                  <TabsTrigger value="orders" className="w-full justify-start">
                    Order History
                  </TabsTrigger>
                  <TabsTrigger value="addresses" className="w-full justify-start">
                    Addresses
                  </TabsTrigger>
                  <TabsTrigger value="password" className="w-full justify-start">
                    Change Password
                  </TabsTrigger>
                </TabsList>
              </Tabs>

              <Button variant="outline" className="w-full mt-6" onClick={handleLogout} disabled={isLoading}>
                {isLoading ? "Logging out..." : "Logout"}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="md:col-span-3">
          <Card>
            <TabsContent value="profile" className="m-0">
              <CardHeader>
                <CardTitle>Profile Information</CardTitle>
                <CardDescription>View and update your personal information</CardDescription>
              </CardHeader>
              <CardContent>
                <form className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First Name</Label>
                      <Input id="firstName" defaultValue={userData.firstName} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input id="lastName" defaultValue={userData.lastName} />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" defaultValue={userData.email} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input id="phone" defaultValue={userData.phone} />
                    </div>
                  </div>

                  <Button className="bg-gray-700 hover:bg-gray-800">Save Changes</Button>
                </form>
              </CardContent>
            </TabsContent>

            <TabsContent value="orders" className="m-0">
              <CardHeader>
                <CardTitle>Order History</CardTitle>
                <CardDescription>View your past orders and their status</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Order ID</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Items</TableHead>
                      <TableHead>Total</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orderHistory.map((order) => (
                      <TableRow key={order.id}>
                        <TableCell className="font-medium">{order.id}</TableCell>
                        <TableCell>{order.date}</TableCell>
                        <TableCell>{order.items}</TableCell>
                        <TableCell>{order.total}</TableCell>
                        <TableCell>
                          <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">
                            {order.status}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="outline" size="sm">
                            View Details
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </TabsContent>

            <TabsContent value="addresses" className="m-0">
              <CardHeader>
                <CardTitle>Saved Addresses</CardTitle>
                <CardDescription>Manage your delivery addresses</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">Home Address</CardTitle>
                        <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">Default</span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p>{userData.address}</p>
                      <p>
                        {userData.city}, {userData.region}
                      </p>
                      <div className="flex gap-2 mt-4">
                        <Button variant="outline" size="sm">
                          Edit
                        </Button>
                        <Button variant="outline" size="sm" className="text-red-500">
                          Delete
                        </Button>
                      </div>
                    </CardContent>
                  </Card>

                  <Button className="bg-gray-700 hover:bg-gray-800">Add New Address</Button>
                </div>
              </CardContent>
            </TabsContent>

            <TabsContent value="password" className="m-0">
              <CardHeader>
                <CardTitle>Change Password</CardTitle>
                <CardDescription>Update your password to keep your account secure</CardDescription>
              </CardHeader>
              <CardContent>
                <form className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="currentPassword">Current Password</Label>
                    <Input id="currentPassword" type="password" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="newPassword">New Password</Label>
                    <Input id="newPassword" type="password" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirm New Password</Label>
                    <Input id="confirmPassword" type="password" />
                  </div>
                  <Button className="bg-gray-700 hover:bg-gray-800">Update Password</Button>
                </form>
              </CardContent>
            </TabsContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
