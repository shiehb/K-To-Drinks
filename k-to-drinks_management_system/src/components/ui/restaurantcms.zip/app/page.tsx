import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gray-100 py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">ARQUILITAS Restaurant</h1>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Experience the rich flavors of the Philippines with our traditional dishes
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-amber-600 hover:bg-amber-700">
              <Link href="/menu">View Menu</Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link href="/login">Login</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Featured Items */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Our Specialties</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[1, 2, 3].map((item) => (
              <div key={item} className="rounded-lg overflow-hidden shadow-md">
                <div className="relative h-64 w-full bg-gray-200">
                  {/* Use placeholder images instead of external URLs */}
                  <Image
                    src={`/placeholder.svg?height=300&width=300`}
                    alt={`Filipino dish ${item}`}
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-4">
                  <h3 className="text-xl font-semibold mb-2">Filipino Dish {item}</h3>
                  <p className="text-gray-600 mb-4">Traditional Filipino dish made with authentic ingredients.</p>
                  <Button asChild variant="outline" className="w-full">
                    <Link href="/menu">View Details</Link>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
