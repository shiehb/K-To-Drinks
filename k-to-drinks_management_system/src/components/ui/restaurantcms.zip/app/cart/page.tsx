"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Trash2 } from "lucide-react"

// Sample cart data
const initialCartItems = [
  {
    id: "1",
    name: "Lumpia Shanghai",
    price: 8.99,
    quantity: 2,
    image: "https://images.unsplash.com/photo-1625398407796-82650a8c9dd1?q=80&w=2069&auto=format&fit=crop",
  },
  {
    id: "4",
    name: "Adobo",
    price: 14.99,
    quantity: 1,
    image: "https://images.unsplash.com/photo-1599122759357-66745a5c36ce?q=80&w=2070&auto=format&fit=crop",
  },
]

export default function CartPage() {
  const [cartItems, setCartItems] = useState(initialCartItems)

  const updateQuantity = (id: string, newQuantity: number) => {
    if (newQuantity < 1) return

    setCartItems(cartItems.map((item) => (item.id === id ? { ...item, quantity: newQuantity } : item)))
  }

  const removeItem = (id: string) => {
    setCartItems(cartItems.filter((item) => item.id !== id))
  }

  const subtotal = cartItems.reduce((total, item) => total + item.price * item.quantity, 0)
  const shipping = 5.99
  const total = subtotal + shipping

  return (
    <div className="container mx-auto py-12 px-4">
      <h1 className="text-3xl font-bold mb-8">Your Cart</h1>

      {cartItems.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-xl mb-6">Your cart is empty</p>
          <Button asChild className="bg-amber-600 hover:bg-amber-700">
            <Link href="/menu">Continue Shopping</Link>
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="border rounded-lg overflow-hidden">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Product</th>
                    <th className="px-4 py-3 text-center text-sm font-medium text-gray-500">Quantity</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Price</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Total</th>
                    <th className="px-4 py-3 text-right text-sm font-medium text-gray-500"></th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {cartItems.map((item) => (
                    <tr key={item.id}>
                      <td className="px-4 py-4">
                        <div className="flex items-center">
                          <div className="relative h-16 w-16 rounded overflow-hidden mr-4">
                            <Image
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              fill
                              className="object-cover"
                            />
                          </div>
                          <span className="font-medium">{item.name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center justify-center">
                          <button
                            className="w-8 h-8 flex items-center justify-center border rounded-l"
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          >
                            -
                          </button>
                          <Input
                            type="number"
                            value={item.quantity}
                            onChange={(e) => updateQuantity(item.id, Number.parseInt(e.target.value) || 1)}
                            className="w-12 h-8 text-center border-y rounded-none"
                          />
                          <button
                            className="w-8 h-8 flex items-center justify-center border rounded-r"
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          >
                            +
                          </button>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-right">${item.price.toFixed(2)}</td>
                      <td className="px-4 py-4 text-right">${(item.price * item.quantity).toFixed(2)}</td>
                      <td className="px-4 py-4 text-right">
                        <button className="text-red-500 hover:text-red-700" onClick={() => removeItem(item.id)}>
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <div className="border rounded-lg p-6">
              <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
              <div className="space-y-3 mb-6">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Shipping</span>
                  <span>${shipping.toFixed(2)}</span>
                </div>
                <div className="border-t pt-3 flex justify-between font-semibold">
                  <span>Total</span>
                  <span>${total.toFixed(2)}</span>
                </div>
              </div>
              <Button asChild className="w-full bg-amber-600 hover:bg-amber-700">
                <Link href="/checkout">Proceed to Checkout</Link>
              </Button>
              <div className="mt-4 text-center">
                <Link href="/menu" className="text-sm text-amber-600 hover:underline">
                  Continue Shopping
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
