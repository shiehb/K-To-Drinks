import { Input } from "@/components/ui/input"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

// Sample blog data
const blogPosts = [
  {
    id: 1,
    title: "Summer Menu Launch: Fresh Flavors for the Season",
    excerpt:
      "Discover our new summer menu featuring seasonal ingredients and refreshing dishes perfect for warm weather dining.",
    date: "May 5, 2025",
    author: "Chef Maria Rodriguez",
    category: "Menu Updates",
    image: "/placeholder.svg?height=600&width=800",
    slug: "summer-menu-launch",
  },
  {
    id: 2,
    title: "Meet Our New Head Chef: James Chen",
    excerpt:
      "We're excited to welcome Chef James Chen to our culinary team. Learn about his background and the new flavors he's bringing to our restaurant.",
    date: "April 20, 2025",
    author: "Sarah Johnson",
    category: "Team News",
    image: "/placeholder.svg?height=600&width=800",
    slug: "meet-our-new-chef",
  },
  {
    id: 3,
    title: "The Art of Pasta Making: Techniques from Our Kitchen",
    excerpt:
      "Dive into the traditional methods we use to create our handmade pasta and learn some tips you can try at home.",
    date: "April 10, 2025",
    author: "Chef Maria Rodriguez",
    category: "Cooking Tips",
    image: "/placeholder.svg?height=600&width=800",
    slug: "art-of-pasta-making",
  },
  {
    id: 4,
    title: "Wine Pairing Guide: Perfect Matches for Our Signature Dishes",
    excerpt:
      "Our sommelier shares expert advice on selecting the perfect wine to complement your meal and enhance your dining experience.",
    date: "March 28, 2025",
    author: "David Wilson",
    category: "Wine & Beverages",
    image: "/placeholder.svg?height=600&width=800",
    slug: "wine-pairing-guide",
  },
  {
    id: 5,
    title: "Behind the Scenes: A Day in Our Kitchen",
    excerpt:
      "Take a peek behind the scenes and discover what goes into preparing for a busy service at Savory Delights.",
    date: "March 15, 2025",
    author: "Chef James Chen",
    category: "Restaurant Life",
    image: "/placeholder.svg?height=600&width=800",
    slug: "behind-the-scenes",
  },
  {
    id: 6,
    title: "Sustainable Dining: Our Commitment to the Environment",
    excerpt:
      "Learn about our initiatives to reduce waste, source locally, and minimize our environmental impact while serving delicious food.",
    date: "March 5, 2025",
    author: "Sarah Johnson",
    category: "Sustainability",
    image: "/placeholder.svg?height=600&width=800",
    slug: "sustainable-dining",
  },
]

export default function BlogPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Restaurant Blog</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Explore our latest articles, cooking tips, and restaurant updates. Get a taste of what's happening at Savory
          Delights.
        </p>
      </div>

      {/* Featured Post */}
      <div className="mb-16">
        <Card className="overflow-hidden">
          <div className="grid md:grid-cols-2">
            <div className="relative h-64 md:h-auto">
              <Image
                src={blogPosts[0].image || "/placeholder.svg"}
                alt={blogPosts[0].title}
                fill
                className="object-cover"
              />
            </div>
            <div className="p-6 md:p-8 flex flex-col justify-center">
              <div className="mb-2">
                <span className="inline-block bg-amber-100 text-amber-800 text-xs font-medium px-2.5 py-0.5 rounded">
                  {blogPosts[0].category}
                </span>
              </div>
              <h2 className="text-2xl font-bold mb-4">{blogPosts[0].title}</h2>
              <p className="text-gray-600 mb-6">{blogPosts[0].excerpt}</p>
              <div className="flex items-center justify-between mt-auto">
                <div className="text-sm text-gray-500">
                  <span>{blogPosts[0].date}</span>
                  <span className="mx-2">•</span>
                  <span>By {blogPosts[0].author}</span>
                </div>
                <Button asChild className="bg-amber-600 hover:bg-amber-700">
                  <Link href={`/blog/${blogPosts[0].slug}`}>Read More</Link>
                </Button>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Recent Posts */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-8">Recent Articles</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.slice(1).map((post) => (
            <Card key={post.id} className="overflow-hidden flex flex-col h-full">
              <div className="relative h-48">
                <Image src={post.image || "/placeholder.svg"} alt={post.title} fill className="object-cover" />
              </div>
              <CardHeader className="pb-2">
                <div className="mb-2">
                  <span className="inline-block bg-amber-100 text-amber-800 text-xs font-medium px-2.5 py-0.5 rounded">
                    {post.category}
                  </span>
                </div>
                <CardTitle className="text-xl">{post.title}</CardTitle>
                <CardDescription className="text-sm text-gray-500">
                  {post.date} • By {post.author}
                </CardDescription>
              </CardHeader>
              <CardContent className="pb-2 flex-grow">
                <p className="text-gray-600">{post.excerpt}</p>
              </CardContent>
              <CardFooter>
                <Button asChild variant="outline" className="w-full">
                  <Link href={`/blog/${post.slug}`}>Read Article</Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>

      {/* Categories */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-6">Browse by Category</h2>
        <div className="flex flex-wrap gap-4">
          {[
            "All",
            "Menu Updates",
            "Cooking Tips",
            "Team News",
            "Restaurant Life",
            "Wine & Beverages",
            "Sustainability",
            "Events",
          ].map((category) => (
            <Button key={category} variant="outline" className="rounded-full">
              {category}
            </Button>
          ))}
        </div>
      </div>

      {/* Newsletter Signup */}
      <div className="bg-amber-50 p-8 rounded-lg">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-2xl font-semibold mb-4">Subscribe to Our Newsletter</h2>
          <p className="text-gray-600 mb-6">
            Stay updated with our latest menu items, special events, and exclusive offers.
          </p>
          <div className="flex flex-col sm:flex-row gap-2">
            <Input type="email" placeholder="Enter your email" className="flex-grow" />
            <Button className="bg-amber-600 hover:bg-amber-700">Subscribe</Button>
          </div>
        </div>
      </div>
    </div>
  )
}
