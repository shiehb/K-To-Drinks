import Image from "next/image"
import { Button } from "@/components/ui/button"

// Sample shop data
const shopItems = [
  {
    id: "1",
    name: "Filipino Soy Sauce",
    description: "Traditional Filipino soy sauce, perfect for dipping or cooking.",
    price: 5.99,
    image: "https://images.unsplash.com/photo-1590301157890-4810ed352733?q=80&w=2070&auto=format&fit=crop",
  },
  {
    id: "2",
    name: "Calamansi Juice",
    description: "Refreshing juice made from the Filipino citrus fruit calamansi.",
    price: 3.99,
    image: "https://images.unsplash.com/photo-1596392301391-8a8641869d68?q=80&w=2070&auto=format&fit=crop",
  },
  {
    id: "3",
    name: "Ube Jam",
    description: "Sweet purple yam jam, a Filipino delicacy.",
    price: 7.99,
    image: "https://images.unsplash.com/photo-1528975604071-b4dc52a2d18c?q=80&w=2070&auto=format&fit=crop",
  },
  {
    id: "4",
    name: "Banana Ketchup",
    description: "A uniquely Filipino condiment made from bananas instead of tomatoes.",
    price: 4.99,
    image: "https://images.unsplash.com/photo-1471943311424-646960669fbc?q=80&w=2070&auto=format&fit=crop",
  },
  {
    id: "5",
    name: "Dried Mangoes",
    description: "Sweet and tangy dried Philippine mangoes.",
    price: 6.99,
    image: "https://images.unsplash.com/photo-1553279768-865429fa0078?q=80&w=2070&auto=format&fit=crop",
  },
  {
    id: "6",
    name: "Coconut Vinegar",
    description: "Tangy vinegar made from the sap of coconut palms.",
    price: 5.49,
    image: "https://images.unsplash.com/photo-1620574387735-3624d75b2dbc?q=80&w=2070&auto=format&fit=crop",
  },
]

export default function ShopPage() {
  return (
    <div className="container mx-auto py-12 px-4">
      <h1 className="text-3xl md:text-4xl font-bold text-center mb-12">Shop Filipino Products</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {shopItems.map((item) => (
          <div key={item.id} className="border rounded-lg overflow-hidden shadow-sm">
            <div className="relative h-48 w-full">
              <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
            </div>
            <div className="p-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-lg font-semibold">{item.name}</h3>
                <span className="text-amber-600 font-medium">${item.price.toFixed(2)}</span>
              </div>
              <p className="text-gray-600 text-sm mb-4">{item.description}</p>
              <Button className="w-full bg-amber-600 hover:bg-amber-700">Add to Cart</Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
