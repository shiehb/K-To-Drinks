import { Button } from "@/components/ui/button"

export default function ConfirmationPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Order Confirmation</h1>
      <hr className="mb-12" />

      <div className="max-w-md mx-auto">
        <div className="border p-8 text-center mb-8">
          <h2 className="text-2xl font-bold mb-8">SUCCESS</h2>

          <div className="space-y-4 text-left mb-8">
            <div className="flex justify-between">
              <span>AMOUNT PAID:</span>
              <span>PHP 1,500</span>
            </div>
            <div className="flex justify-between">
              <span>ORDER NUMBER:</span>
              <span>69</span>
            </div>
            <div className="flex justify-between">
              <span>REF NUMBER:</span>
              <span>12-34-56</span>
            </div>
          </div>

          <Button className="w-full bg-gray-700 hover:bg-gray-800">OKAY</Button>
        </div>

        <p className="text-center">Please wait. The regional branch will call you shortly.</p>
      </div>
    </div>
  )
}
