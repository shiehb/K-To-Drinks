import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Image from "next/image"

export default function MenuPage() {
  // Sample menu items
  const menuItems = [
    {
      id: 1,
      name: "Adobo",
      description: "Chicken or pork marinated in soy sauce, vinegar, and spices.",
      price: "$12.99",
      category: "Main Dishes",
    },
    {
      id: 2,
      name: "Sinigang",
      description: "Sour soup with meat and vegetables.",
      price: "$14.99",
      category: "Soups",
    },
    {
      id: 3,
      name: "Pancit",
      description: "Stir-fried noodles with meat and vegetables.",
      price: "$10.99",
      category: "Noodles",
    },
    {
      id: 4,
      name: "Lumpia",
      description: "Filipino spring rolls filled with meat and vegetables.",
      price: "$8.99",
      category: "Appetizers",
    },
    {
      id: 5,
      name: "Halo-Halo",
      description: "Mixed dessert with shaved ice, sweet beans, fruits, and ice cream.",
      price: "$7.99",
      category: "Desserts",
    },
    {
      id: 6,
      name: "Lechon Kawali",
      description: "Deep-fried pork belly with crispy skin.",
      price: "$15.99",
      category: "Main Dishes",
    },
  ]

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl md:text-4xl font-bold text-center mb-12">Our Menu</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {menuItems.map((item) => (
          <Card key={item.id} className="overflow-hidden">
            <div className="relative h-48 w-full bg-gray-200">
              <Image
                src={`/placeholder.svg?height=200&width=400&text=${item.name}`}
                alt={item.name}
                fill
                className="object-cover"
              />
            </div>
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-xl font-semibold">{item.name}</h3>
                <span className="text-amber-600 font-bold">{item.price}</span>
              </div>
              <p className="text-gray-600 mb-2">{item.description}</p>
              <div className="flex justify-between items-center mt-4">
                <span className="text-sm text-gray-500">{item.category}</span>
                <Button size="sm" className="bg-amber-600 hover:bg-amber-700">
                  Order Now
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
