import { NextResponse } from "next/server"
import { removeTokenCookie } from "@/lib/auth"

export async function POST() {
  try {
    const response = NextResponse.json({ success: true }, { status: 200 })

    // Remove token cookie
    removeTokenCookie(response)

    return response
  } catch (error) {
    console.error("Logout error:", error)
    return NextResponse.json({ error: "An error occurred during logout" }, { status: 500 })
  }
}
