import { NextResponse } from "next/server"
import prisma from "@/lib/db"
import bcrypt from "bcryptjs"
import { getCurrentUser } from "@/lib/auth"

export async function POST() {
  try {
    // Check if user is admin
    const user = await getCurrentUser()

    if (!user || user.role !== "admin") {
      return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 })
    }

    // Create admin user
    const adminPassword = await bcrypt.hash("admin123", 10)
    await prisma.user.upsert({
      where: { email: "admin@example.com" },
      update: {},
      create: {
        name: "Admin User",
        email: "admin@example.com",
        password: adminPassword,
        role: "admin",
      },
    })

    // Create regular user
    const userPassword = await bcrypt.hash("password123", 10)
    await prisma.user.upsert({
      where: { email: "user@example.com" },
      update: {},
      create: {
        name: "Regular User",
        email: "user@example.com",
        password: userPassword,
        role: "user",
      },
    })

    // Create products
    const products = [
      {
        name: "Lumpia Shanghai",
        description: "Filipino spring rolls filled with ground pork, minced vegetables, and seasonings.",
        price: 8.99,
        image: "https://images.unsplash.com/photo-1625398407796-82650a8c9dd4?q=80&w=800",
        category: "Appetizers",
      },
      {
        name: "Chicken Adobo",
        description:
          "Chicken marinated in vinegar, soy sauce, garlic, and spices, then browned in oil and simmered in the marinade.",
        price: 14.99,
        image: "https://images.unsplash.com/photo-1623595119708-26b1f7500ddd?q=80&w=800",
        category: "Main Courses",
      },
      {
        name: "Pancit Bihon",
        description: "Stir-fried rice noodles with meat and vegetables, seasoned with soy sauce and calamansi.",
        price: 12.99,
        image: "https://images.unsplash.com/photo-1619221882266-c9b580be28b3?q=80&w=800",
        category: "Main Courses",
      },
      {
        name: "Halo-Halo",
        description: "A popular Filipino dessert with shaved ice, sweet beans, fruits, jellies, and ice cream.",
        price: 7.99,
        image: "https://images.unsplash.com/photo-1563805042-7684c019e1cb?q=80&w=800",
        category: "Desserts",
      },
      {
        name: "Calamansi Juice",
        description: "Refreshing juice made from the Filipino citrus fruit calamansi.",
        price: 3.99,
        image: "https://images.unsplash.com/photo-1621263764928-df1444c5e859?q=80&w=800",
        category: "Beverages",
      },
    ]

    for (const product of products) {
      await prisma.product.upsert({
        where: { name: product.name },
        update: product,
        create: product,
      })
    }

    return NextResponse.json({
      success: true,
      message: "Database seeded successfully",
    })
  } catch (error) {
    console.error("Error seeding database:", error)
    return NextResponse.json(
      { success: false, message: "An error occurred while seeding the database" },
      { status: 500 },
    )
  }
}
