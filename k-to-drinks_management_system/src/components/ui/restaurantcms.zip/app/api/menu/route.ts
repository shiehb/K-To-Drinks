import { NextResponse } from "next/server"
import prisma from "@/lib/db"

export async function GET() {
  try {
    // Get all products
    const products = await prisma.product.findMany({
      orderBy: {
        name: "asc",
      },
    })

    // Group products by category
    const categories: { [key: string]: any[] } = {}

    products.forEach((product) => {
      if (!categories[product.category]) {
        categories[product.category] = []
      }
      categories[product.category].push(product)
    })

    return NextResponse.json({
      success: true,
      categories,
    })
  } catch (error) {
    console.error("Error fetching menu:", error)
    return NextResponse.json({ success: false, message: "An error occurred while fetching the menu" }, { status: 500 })
  }
}
