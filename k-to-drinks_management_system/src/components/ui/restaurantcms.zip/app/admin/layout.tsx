"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useToast } from "@/components/ui/use-toast"
import { checkAdminAuth } from "@/lib/auth-utils"

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()
  const { toast } = useToast()
  const [isAuthorized, setIsAuthorized] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const verifyAdmin = async () => {
      try {
        const isAdmin = await checkAdminAuth()

        if (!isAdmin) {
          toast({
            title: "Access denied",
            description: "You don't have permission to access the admin dashboard",
            variant: "destructive",
          })
          router.push("/login")
        } else {
          setIsAuthorized(true)
        }
      } catch (error) {
        console.error("Admin authentication error:", error)
        router.push("/login")
      } finally {
        setIsLoading(false)
      }
    }

    verifyAdmin()
  }, [router, toast])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-amber-600"></div>
      </div>
    )
  }

  // Only render children if authorized
  return isAuthorized ? <>{children}</> : null
}
