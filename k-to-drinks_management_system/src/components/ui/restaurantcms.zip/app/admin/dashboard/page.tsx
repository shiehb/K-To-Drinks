"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { BarChart, Home, LogOut, Package, Settings, ShoppingBag, Users } from "lucide-react"
import { checkAdminAuth } from "@/lib/auth-utils"

// Sample data
const orders = [
  {
    id: 1,
    customer: "Juan Dela Cruz",
    date: "2025-05-10",
    total: "₱1,250",
    status: "Delivered",
    items: 3,
  },
  {
    id: 2,
    customer: "Maria Santos",
    date: "2025-05-10",
    total: "₱850",
    status: "Processing",
    items: 2,
  },
  {
    id: 3,
    customer: "Pedro Reyes",
    date: "2025-05-11",
    total: "₱1,500",
    status: "Pending",
    items: 4,
  },
  {
    id: 4,
    customer: "Ana Gonzales",
    date: "2025-05-12",
    total: "₱950",
    status: "Delivered",
    items: 2,
  },
  {
    id: 5,
    customer: "Jose Rizal",
    date: "2025-05-13",
    total: "₱2,100",
    status: "Cancelled",
    items: 5,
  },
]

const products = [
  {
    id: 1,
    name: "Adobo Sauce",
    category: "Sauces",
    price: 180,
    stock: 45,
    featured: true,
    image: "/placeholder.svg?height=100&width=100",
  },
  {
    id: 2,
    name: "Dried Mangoes",
    category: "Snacks",
    price: 150,
    stock: 78,
    featured: true,
    image: "/placeholder.svg?height=100&width=100",
  },
  {
    id: 3,
    name: "Barako Coffee",
    category: "Beverages",
    price: 250,
    stock: 32,
    featured: true,
    image: "/placeholder.svg?height=100&width=100",
  },
  {
    id: 4,
    name: "Banana Chips",
    category: "Snacks",
    price: 120,
    stock: 56,
    featured: false,
    image: "/placeholder.svg?height=100&width=100",
  },
  {
    id: 5,
    name: "Calamansi Juice",
    category: "Beverages",
    price: 95,
    stock: 28,
    featured: false,
    image: "/placeholder.svg?height=100&width=100",
  },
]

const users = [
  {
    id: 1,
    name: "Juan Dela Cruz",
    email: "juan@example.com",
    role: "Customer",
    orders: 8,
    joined: "2025-01-15",
  },
  {
    id: 2,
    name: "Maria Santos",
    email: "maria@example.com",
    role: "Customer",
    orders: 5,
    joined: "2025-02-20",
  },
  {
    id: 3,
    name: "Admin User",
    email: "admin@example.com",
    role: "Admin",
    orders: 0,
    joined: "2024-12-01",
  },
  {
    id: 4,
    name: "Pedro Reyes",
    email: "pedro@example.com",
    role: "Customer",
    orders: 12,
    joined: "2025-01-05",
  },
  {
    id: 5,
    name: "Ana Gonzales",
    email: "ana@example.com",
    role: "Customer",
    orders: 3,
    joined: "2025-03-10",
  },
]

export default function AdminDashboard() {
  const router = useRouter()
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("overview")
  const [isLoading, setIsLoading] = useState(true)
  const [newProduct, setNewProduct] = useState({
    name: "",
    category: "",
    price: "",
    stock: "",
    featured: false,
  })

  useEffect(() => {
    const verifyAdmin = async () => {
      const isAdmin = await checkAdminAuth()

      if (!isAdmin) {
        toast({
          title: "Access denied",
          description: "You don't have permission to access the admin dashboard",
          variant: "destructive",
        })
        router.push("/login")
      } else {
        setIsLoading(false)
      }
    }

    verifyAdmin()
  }, [router, toast])

  const handleLogout = () => {
    // Clear auth data
    localStorage.removeItem("authToken")
    localStorage.removeItem("userRole")

    toast({
      title: "Logged out",
      description: "You have been successfully logged out",
    })

    router.push("/login")
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-amber-600"></div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="hidden md:flex flex-col w-64 bg-white border-r">
        <div className="p-4 border-b">
          <h2 className="font-bold text-xl">Admin Dashboard</h2>
        </div>
        <nav className="flex-1 p-4">
          <ul className="space-y-1">
            <li>
              <button
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md ${
                  activeTab === "overview" ? "bg-amber-50 text-amber-800" : "hover:bg-gray-100"
                }`}
                onClick={() => setActiveTab("overview")}
              >
                <Home className="h-5 w-5" />
                <span>Overview</span>
              </button>
            </li>
            <li>
              <button
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md ${
                  activeTab === "orders" ? "bg-amber-50 text-amber-800" : "hover:bg-gray-100"
                }`}
                onClick={() => setActiveTab("orders")}
              >
                <ShoppingBag className="h-5 w-5" />
                <span>Orders</span>
              </button>
            </li>
            <li>
              <button
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md ${
                  activeTab === "products" ? "bg-amber-50 text-amber-800" : "hover:bg-gray-100"
                }`}
                onClick={() => setActiveTab("products")}
              >
                <Package className="h-5 w-5" />
                <span>Products</span>
              </button>
            </li>
            <li>
              <button
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md ${
                  activeTab === "users" ? "bg-amber-50 text-amber-800" : "hover:bg-gray-100"
                }`}
                onClick={() => setActiveTab("users")}
              >
                <Users className="h-5 w-5" />
                <span>Users</span>
              </button>
            </li>
            <li>
              <button
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md ${
                  activeTab === "analytics" ? "bg-amber-50 text-amber-800" : "hover:bg-gray-100"
                }`}
                onClick={() => setActiveTab("analytics")}
              >
                <BarChart className="h-5 w-5" />
                <span>Analytics</span>
              </button>
            </li>
            <li>
              <button
                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md ${
                  activeTab === "settings" ? "bg-amber-50 text-amber-800" : "hover:bg-gray-100"
                }`}
                onClick={() => setActiveTab("settings")}
              >
                <Settings className="h-5 w-5" />
                <span>Settings</span>
              </button>
            </li>
          </ul>
        </nav>
        <div className="p-4 border-t">
          <Button
            variant="outline"
            className="w-full flex items-center justify-center space-x-2"
            onClick={handleLogout}
          >
            <LogOut className="h-4 w-4" />
            <span>Logout</span>
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <header className="bg-white border-b p-4 flex items-center justify-between sticky top-0 z-10">
          <h1 className="text-xl font-semibold">
            {activeTab === "overview" && "Dashboard Overview"}
            {activeTab === "orders" && "Order Management"}
            {activeTab === "products" && "Product Management"}
            {activeTab === "users" && "User Management"}
            {activeTab === "analytics" && "Analytics"}
            {activeTab === "settings" && "Settings"}
          </h1>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-600">Welcome, Admin</span>
            <Button variant="outline" size="sm" className="md:hidden" onClick={handleLogout}>
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </header>

        <main className="p-6">
          {/* Overview Tab */}
          {activeTab === "overview" && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">42</div>
                    <p className="text-xs text-green-500 mt-1">+15% from last week</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Total Products</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">28</div>
                    <p className="text-xs text-muted-foreground mt-1">5 categories</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">156</div>
                    <p className="text-xs text-green-500 mt-1">+12% from last month</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">₱45,250</div>
                    <p className="text-xs text-green-500 mt-1">+8% from last month</p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Orders</CardTitle>
                    <CardDescription>Latest customer orders</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Customer</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {orders.slice(0, 5).map((order) => (
                          <TableRow key={order.id}>
                            <TableCell>{order.customer}</TableCell>
                            <TableCell>{order.date}</TableCell>
                            <TableCell>
                              <span
                                className={`px-2 py-1 rounded-full text-xs ${
                                  order.status === "Delivered"
                                    ? "bg-green-100 text-green-800"
                                    : order.status === "Processing" || order.status === "Pending"
                                      ? "bg-amber-100 text-amber-800"
                                      : "bg-red-100 text-red-800"
                                }`}
                              >
                                {order.status}
                              </span>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                    <div className="mt-4 text-center">
                      <Button variant="outline" size="sm" onClick={() => setActiveTab("orders")}>
                        View All Orders
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Popular Products</CardTitle>
                    <CardDescription>Best selling products this month</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Product</TableHead>
                          <TableHead>Category</TableHead>
                          <TableHead>Price</TableHead>
                          <TableHead>Stock</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {products
                          .filter((product) => product.featured)
                          .map((product) => (
                            <TableRow key={product.id}>
                              <TableCell>{product.name}</TableCell>
                              <TableCell>{product.category}</TableCell>
                              <TableCell>₱{product.price.toFixed(2)}</TableCell>
                              <TableCell>{product.stock}</TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                    <div className="mt-4 text-center">
                      <Button variant="outline" size="sm" onClick={() => setActiveTab("products")}>
                        Manage Products
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {/* Orders Tab */}
          {activeTab === "orders" && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h2 className="text-xl font-semibold">Order Management</h2>
                <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                  <Input placeholder="Search orders..." className="w-full sm:w-64" />
                  <Select defaultValue="all">
                    <SelectTrigger className="w-full sm:w-[180px]">
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Orders</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="processing">Processing</SelectItem>
                      <SelectItem value="delivered">Delivered</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Card>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Order ID</TableHead>
                          <TableHead>Customer</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Items</TableHead>
                          <TableHead>Total</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {orders.map((order) => (
                          <TableRow key={order.id}>
                            <TableCell className="font-medium">#{order.id}</TableCell>
                            <TableCell>{order.customer}</TableCell>
                            <TableCell>{order.date}</TableCell>
                            <TableCell>{order.items}</TableCell>
                            <TableCell>{order.total}</TableCell>
                            <TableCell>
                              <span
                                className={`px-2 py-1 rounded-full text-xs ${
                                  order.status === "Delivered"
                                    ? "bg-green-100 text-green-800"
                                    : order.status === "Processing" || order.status === "Pending"
                                      ? "bg-amber-100 text-amber-800"
                                      : "bg-red-100 text-red-800"
                                }`}
                              >
                                {order.status}
                              </span>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <Button variant="outline" size="sm">
                                  View
                                </Button>
                                <Select defaultValue={order.status.toLowerCase()}>
                                  <SelectTrigger className="h-8 w-[130px]">
                                    <SelectValue placeholder="Update Status" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="pending">Pending</SelectItem>
                                    <SelectItem value="processing">Processing</SelectItem>
                                    <SelectItem value="delivered">Delivered</SelectItem>
                                    <SelectItem value="cancelled">Cancelled</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Products Tab */}
          {activeTab === "products" && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h2 className="text-xl font-semibold">Product Management</h2>
                <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                  <Input placeholder="Search products..." className="w-full sm:w-64" />
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button className="bg-amber-600 hover:bg-amber-700 w-full sm:w-auto">Add New Product</Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[550px]">
                      <DialogHeader>
                        <DialogTitle>Add New Product</DialogTitle>
                        <DialogDescription>Create a new product to add to your store.</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <div className="space-y-2">
                          <Label htmlFor="name">Product Name</Label>
                          <Input id="name" placeholder="Enter product name" />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="category">Category</Label>
                            <Select>
                              <SelectTrigger>
                                <SelectValue placeholder="Select category" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="sauces">Sauces</SelectItem>
                                <SelectItem value="snacks">Snacks</SelectItem>
                                <SelectItem value="beverages">Beverages</SelectItem>
                                <SelectItem value="desserts">Desserts</SelectItem>
                                <SelectItem value="ingredients">Ingredients</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="price">Price (₱)</Label>
                            <Input id="price" type="number" step="0.01" placeholder="0.00" />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="stock">Stock Quantity</Label>
                            <Input id="stock" type="number" placeholder="0" />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="sku">SKU (Optional)</Label>
                            <Input id="sku" placeholder="Enter SKU" />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="description">Description</Label>
                          <Textarea id="description" placeholder="Enter product description" rows={3} />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="image">Product Image</Label>
                          <Input id="image" type="file" />
                        </div>
                        <div className="flex items-center space-x-2">
                          <input type="checkbox" id="featured" className="rounded text-amber-600" />
                          <Label htmlFor="featured">Featured product</Label>
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline">Cancel</Button>
                        <Button className="bg-amber-600 hover:bg-amber-700">Save Product</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>

              <Tabs defaultValue="all">
                <TabsList>
                  <TabsTrigger value="all">All Products</TabsTrigger>
                  <TabsTrigger value="sauces">Sauces</TabsTrigger>
                  <TabsTrigger value="snacks">Snacks</TabsTrigger>
                  <TabsTrigger value="beverages">Beverages</TabsTrigger>
                  <TabsTrigger value="featured">Featured</TabsTrigger>
                </TabsList>
                <TabsContent value="all" className="mt-6">
                  <Card>
                    <CardContent className="p-0">
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Image</TableHead>
                              <TableHead>Name</TableHead>
                              <TableHead>Category</TableHead>
                              <TableHead>Price</TableHead>
                              <TableHead>Stock</TableHead>
                              <TableHead>Featured</TableHead>
                              <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {products.map((product) => (
                              <TableRow key={product.id}>
                                <TableCell>
                                  <div className="h-10 w-10 rounded-md bg-gray-200 relative">
                                    <Image
                                      src={product.image || "/placeholder.svg"}
                                      alt={product.name}
                                      fill
                                      className="object-cover rounded-md"
                                    />
                                  </div>
                                </TableCell>
                                <TableCell className="font-medium">{product.name}</TableCell>
                                <TableCell>{product.category}</TableCell>
                                <TableCell>₱{product.price.toFixed(2)}</TableCell>
                                <TableCell>{product.stock}</TableCell>
                                <TableCell>{product.featured ? "Yes" : "No"}</TableCell>
                                <TableCell className="text-right">
                                  <div className="flex justify-end gap-2">
                                    <Button variant="outline" size="sm">
                                      Edit
                                    </Button>
                                    <Button variant="outline" size="sm" className="text-red-500 hover:text-red-700">
                                      Delete
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                {/* Other tabs would have similar content */}
              </Tabs>
            </div>
          )}

          {/* Users Tab */}
          {activeTab === "users" && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <h2 className="text-xl font-semibold">User Management</h2>
                <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                  <Input placeholder="Search users..." className="w-full sm:w-64" />
                  <Select defaultValue="all">
                    <SelectTrigger className="w-full sm:w-[180px]">
                      <SelectValue placeholder="Filter by role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Users</SelectItem>
                      <SelectItem value="admin">Admins</SelectItem>
                      <SelectItem value="customer">Customers</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Card>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Role</TableHead>
                          <TableHead>Orders</TableHead>
                          <TableHead>Joined</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {users.map((user) => (
                          <TableRow key={user.id}>
                            <TableCell className="font-medium">{user.name}</TableCell>
                            <TableCell>{user.email}</TableCell>
                            <TableCell>
                              <span
                                className={`px-2 py-1 rounded-full text-xs ${
                                  user.role === "Admin" ? "bg-purple-100 text-purple-800" : "bg-blue-100 text-blue-800"
                                }`}
                              >
                                {user.role}
                              </span>
                            </TableCell>
                            <TableCell>{user.orders}</TableCell>
                            <TableCell>{user.joined}</TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <Button variant="outline" size="sm">
                                  View
                                </Button>
                                <Button variant="outline" size="sm">
                                  Edit
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Other tabs would have similar content structure */}
          {(activeTab === "analytics" || activeTab === "settings") && (
            <div className="flex items-center justify-center h-64 bg-gray-100 rounded-lg">
              <p className="text-gray-500">This section is under development</p>
            </div>
          )}
        </main>
      </div>
    </div>
  )
}
