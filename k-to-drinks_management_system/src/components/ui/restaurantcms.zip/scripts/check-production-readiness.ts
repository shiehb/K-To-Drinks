import fs from "fs"
import path from "path"

// Define the checks to perform
const checks = [
  {
    name: "Environment Variables",
    check: () => {
      const envExample = fs.readFileSync(path.join(process.cwd(), ".env.example"), "utf8")
      const requiredVars = envExample
        .split("\n")
        .filter((line) => !line.startsWith("#") && line.includes("="))
        .map((line) => line.split("=")[0].trim())

      const missingVars = requiredVars.filter((varName) => !process.env[varName])

      if (missingVars.length > 0) {
        return {
          passed: false,
          message: `Missing required environment variables: ${missingVars.join(", ")}`,
        }
      }

      return { passed: true }
    },
  },
  {
    name: "Database Connection",
    check: async () => {
      try {
        const { PrismaClient } = require("@prisma/client")
        const prisma = new PrismaClient()
        await prisma.$connect()
        await prisma.$disconnect()
        return { passed: true }
      } catch (error) {
        return {
          passed: false,
          message: `Failed to connect to database: ${error.message}`,
        }
      }
    },
  },
  {
    name: "Build Process",
    check: async () => {
      try {
        const packageJson = require(path.join(process.cwd(), "package.json"))

        if (!packageJson.scripts.build) {
          return {
            passed: false,
            message: "No build script found in package.json",
          }
        }

        return { passed: true }
      } catch (error) {
        return {
          passed: false,
          message: `Failed to check build process: ${error.message}`,
        }
      }
    },
  },
  {
    name: "Image Optimization",
    check: () => {
      try {
        const nextConfig = require(path.join(process.cwd(), "next.config.mjs"))

        if (!nextConfig.images || !nextConfig.images.domains || nextConfig.images.domains.length === 0) {
          return {
            passed: false,
            message: "No image domains configured in next.config.mjs",
          }
        }

        return { passed: true }
      } catch (error) {
        return {
          passed: false,
          message: `Failed to check image optimization: ${error.message}`,
        }
      }
    },
  },
  {
    name: "Security Headers",
    check: () => {
      try {
        const nextConfig = require(path.join(process.cwd(), "next.config.mjs"))

        if (!nextConfig.headers) {
          return {
            passed: false,
            message: "No security headers configured in next.config.mjs",
          }
        }

        return { passed: true }
      } catch (error) {
        return {
          passed: false,
          message: `Failed to check security headers: ${error.message}`,
        }
      }
    },
  },
]

// Run all checks
async function runChecks() {
  console.log("🔍 Checking production readiness...\n")

  let allPassed = true

  for (const { name, check } of checks) {
    try {
      const result = await check()

      if (result.passed) {
        console.log(`✅ ${name}: Passed`)
      } else {
        console.log(`❌ ${name}: Failed - ${result.message}`)
        allPassed = false
      }
    } catch (error) {
      console.log(`❌ ${name}: Error - ${error.message}`)
      allPassed = false
    }
  }

  console.log("\n")

  if (allPassed) {
    console.log("🎉 All checks passed! Your application is ready for production.")
  } else {
    console.log("⚠️ Some checks failed. Please fix the issues before deploying to production.")
    process.exit(1)
  }
}

runChecks()
